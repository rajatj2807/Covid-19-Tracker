from flask import Flask, render_template, jsonify, request
from Covid import generate_corodinates

app = Flask(__name__)


@app.route('/')
@app.route('/home')
def home_page():
    return render_template('home.html')


@app.route('/get_covid_graph_coordinates', methods=['POST'])
def create_corodinates():
    user_name = request.form['user_name']
    result = generate_corodinates(user_name)
    #print(result['name_edges'])
    return jsonify(result)


if __name__ == '__main__':
    app.run(debug=True)