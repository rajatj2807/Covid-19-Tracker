#!/usr/bin/env python
# coding: utf-8
import pandas as pd
from copy import deepcopy


def generate_corodinates(input_name):
    result = dict()
    temp, nodes, edges=[], [], []

    df=pd.read_csv(r'COVID-19_US1.csv')
    header_name=df.columns

    countries=list(pd.read_csv(r'affected country.csv')['Country Name'])
    states=list(pd.read_csv(r'State_Travelled.csv')['State'])
    symptoms=['cough','fever','tiredness','difficulty breathing','headache']


    df['Quarrantine_flag'] = df.apply(lambda x : 1  if ( x['Travelled in last 60 days']=='Yes' and 
    ( x['State_Travelled'] in states  or x['Country_Travelled'] in countries)
    and
    (True if (x['Symptoms_Description'] !='Not Applicable'  and 
    len(set(x['Symptoms_Description'].split(';')).intersection(symptoms))>=3) else False  ) ) else 0 , axis=1)


    if list(df[df.Name==input_name]['Quarrantine_flag'])[0] == 1:
        result['quarrantine_msg'] = 'Person should be in quarrantine'
    else:
        result['quarrantine_msg'] = 'Person is healthy'

    
    global counter
    counter = 0
    def loop(c):
        global counter
        if c not in list(df['Name']):
            temp.append(c)
            counter =counter+ 1
            nodes.append({ 'id': counter, 'label':c })
        elif c in temp:
            return None
        else:
            ed = dict()
            temp.append(c)
            nodes.append({'id': counter, 'label':c })
            edges.append({'from':c, 'to':list(df[df['Name']==c]['Primary Contact Person'])[0]})
            edges.append({'from':c, 'to':list(df[df['Name']==c]['Secondary Contact Person1'])[0]})
            edges.append({'from':c, 'to':list(df[df['Name']==c]['Secondary Contact Person2'])[0]})
            edges.append({'from':c, 'to':list(df[df['Name']==c]['Secondary Contact Person3'])[0]})
            counter =counter+ 1
            loop(list(df[df['Name']==c]['Primary Contact Person'])[0])
            counter =counter+ 1
            loop(list(df[df['Name']==c]['Secondary Contact Person1'])[0])
            counter =counter+ 1
            loop(list(df[df['Name']==c]['Secondary Contact Person2'])[0])
            counter =counter+ 1
            loop(list(df[df['Name']==c]['Secondary Contact Person3'])[0])
            



    def find_val(x):
        for data in nodes:
            if data:
                #print(data)
                if x == data['label']:
                    return data['id']
        

                

    loop(input_name)



    import pprint
    pp = pprint.PrettyPrinter(indent=4)




    # In[20]:
    
    name_edges = deepcopy(edges)
    result['name_edges'] = name_edges

    for i in edges:
        id=find_val(i["from"])
        i["from"]=id
        id = find_val(i["to"])
        i['to']=id


    #print(temp)

    #pp.pprint(nodes)

    #pp.pprint(edges)

    result['nodes']= nodes
    result['edges']= edges
    
    return result

